import React, { useState } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Button, TextField, Dialog, DialogTitle, DialogContent, DialogActions } from '@mui/material';
import { Card, Box, CardContent, Typography, Grid } from '@material-ui/core';
import theme from "../../styles/theme";
import { classNames } from "../../utils";
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import IconButton from '@mui/material/IconButton';

export default function Panel(
  className = "",
  hideHeader = true,
) {
  // Define the rows state using useState
  const [rows, setRows] = useState([
    { id: 1, username: 'user745', password: 'Toam4PQM' },
    { id: 2, username: 'user844', password: 'GiV2u6Qw' },
    { id: 3, username: 'user4', password: 'wPKZJDPY' },
    { id: 4, username: 'user22', password: 'ycnYVDlj' },
  ]);

  const [openNewPopup, setOpenNewPopup] = useState(false);
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');

  const [editRowData, setEditRowData] = useState(null);
  const [openPopup, setOpenPopup] = useState(false);
  const [editedUsername, setEditedUsername] = useState('');
  const [editedPassword, setEditedPassword] = useState('');
  const [deleteRowData, setDeleteRowData] = useState(null);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);

  const handleAddUser = () => {
    const newUser = {
      id: rows.length + 1,
      username: newUsername,
      password: newPassword
    };
    setRows([...rows, newUser]);
    setNewUsername('');
    setNewPassword('');
    setOpenNewPopup(false);
  };

  const handleEditClick = (rowData) => {
    setEditRowData(rowData);
    setEditedUsername(rowData.username);
    setEditedPassword(rowData.password);
    setOpenPopup(true);
  };

  const handleDeleteClick = (rowData) => {
    setDeleteRowData(rowData);
    setOpenDeleteDialog(true);
  };

  const handlePopupClose = () => {
    setOpenPopup(false);
  };

  const handleDeleteDialogClose = () => {
    setOpenDeleteDialog(false);
  };

  const handleSaveChanges = () => {
    // Update the row data here with the edited values
    setOpenPopup(false);
  };

  const handleDeleteRow = () => {
    // Delete the row from the data
    const updatedRows = rows.filter(row => row !== deleteRowData);
    // Update rows state
    setRows(updatedRows);
    setOpenDeleteDialog(false);
  };

  return (
    <Box className="px-4 py-8">
      <div className='heading_out mb-3' style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: "6px" }}>
        <Typography color={theme.palette.primary.main} className="headline-medium heading_log" marginBottom="6px">
          Users
        </Typography>

        <Button
          type="button"
          variant="outlined"
          className="title-medium"
          sx={{
            width: "160px",
            padding: "8.5px 16px",
            textTransform: "none",
            border: "1px solid #E01E26",
            color: "#E01E26",
            borderRadius: "5px",
            "&:hover": {
              color: "#fff",
              backgroundColor: "var(--redColor)",
              "& svg": {
                fill: "#fff",
              },
            },
          }}
          onClick={() => setOpenNewPopup(true)}
        >
          Add User
        </Button>
      </div>

      <TableContainer
      
        className={classNames(
          `basic-table`,
          className,
        )}
        component={Paper}
      >
        <Table
          aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell>Sr. No</TableCell>
              <TableCell>Username</TableCell>
              <TableCell>Password</TableCell>
              <TableCell sx={{ width: '20px' }}>Edit</TableCell>
              <TableCell sx={{ width: '20px' }}>Delete</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row) => (
              <TableRow
                key={row.id}
                sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
              >
                <TableCell component="th" scope="row">
                  {row.id}
                </TableCell>
                <TableCell>{row.username}</TableCell>
                <TableCell>{row.password}</TableCell>
                <TableCell sx={{ width: '20px' }}>
                  <IconButton
                    style={{
                      color: 'grey',
                      borderRadius: '50%', // Circular border
                      padding: '5px',
                    }}
                    onClick={() => handleEditClick(row)} // Open popup on edit icon click
                  >
                    <EditIcon />
                  </IconButton>
                </TableCell>
                <TableCell sx={{ width: '20px' }}>
                  <IconButton
                    style={{
                      color: 'grey',
                      borderRadius: '50%', // Circular border
                      padding: '5px',
                    }}
                    onClick={() => handleDeleteClick(row)} // Open delete confirmation dialog on delete icon click
                  >
                    <DeleteIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>


 {/* Popup Dialog for adding a new user */}
 <Dialog open={openNewPopup} onClose={() => setOpenNewPopup(false)}>
        <DialogTitle>Add User</DialogTitle>
        <DialogContent>
          <TextField
            label="Username"
            variant="outlined"
            value={newUsername}
            onChange={(e) => setNewUsername(e.target.value)}
            fullWidth
            margin="normal"
          />
          <TextField
            label="Password"
            variant="outlined"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            fullWidth
            margin="normal"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenNewPopup(false)} color="primary">
            Cancel
          </Button>
          <Button onClick={handleAddUser} color="primary">
            Add User
          </Button>
        </DialogActions>
      </Dialog>



      {/* Popup Dialog for editing */}
      <Dialog open={openPopup} onClose={handlePopupClose}>
        <DialogTitle>Edit User</DialogTitle>
        <DialogContent>
          <TextField
            label="Username"
            variant="outlined"
            value={editedUsername}
            onChange={(e) => setEditedUsername(e.target.value)}
            fullWidth
            margin="normal"
          />
          <TextField
            label="Password"
            variant="outlined"
            value={editedPassword}
            onChange={(e) => setEditedPassword(e.target.value)}
            fullWidth
            margin="normal"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handlePopupClose} color="primary">
            Cancel
          </Button>
          <Button onClick={handleSaveChanges} color="primary">
            Save Changes
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={openDeleteDialog} onClose={handleDeleteDialogClose}>
        <DialogTitle>Delete User</DialogTitle>
        <DialogContent>
          <Typography>Are you sure you want to delete this user?</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDeleteDialogClose} color="primary">
            Cancel
          </Button>
          <Button onClick={handleDeleteRow} color="primary">
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
