# Call-Analytics-Frontend
Installation
1) npm install
2) npm start


Credits:
Mohammad Ali Abbas (SR ML ENGR | Team Lead ML)
Anwaar shah (FrontEnd Developer).
Danish Ali (AI Developer )
Ali Murtaza (DevOp Engr)


--------------